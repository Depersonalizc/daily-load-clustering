#include<iostream>
#include"console.h"
#include"P1PriorityQueue.h"
#include"P2Traverse.h"

using namespace std;

int main(){
    cout<<"Problem1:"<<endl;
    PriorityQueueTest();
    cout<<"Problem2:"<<endl;
    TraverseTest();
    return 0;
}
